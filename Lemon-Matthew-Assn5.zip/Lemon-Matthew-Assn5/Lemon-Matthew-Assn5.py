import time
import random

def printTitle():
    print()
    print(format("Devil's Dice",">32s"))
    print()
def printYouAndDevil(myTurn):
    if myTurn:
        print("     ***",end="")
    else:
        print("        ",end="")
    print("you",end="")
    if myTurn:
        print("***                       ",end="")
    else:
        print("                          ",end="")
    if not myTurn:
        print("***",end="")
    else:
        print("   ",end="")
    print("devil",end="")
    if not myTurn:
        print("***")
    else:
        print("   ")
def printTurnScore():
    print("turn           score", end="")
    print("             ", end="")
    print("turn           score")
def printNumberLine(line,die,myPts,devilPts,myTurn,myRndPts,devilRndPts):
    if myRndPts >= line and myRndPts < line+5:
        print(format(myRndPts,">4d"),"=> ",end="")
    else:
        print("        ",end="")
    print(format(line,">3d"),end="")
    if myPts >= line and myPts < line+5:
        print(" <=",format(myPts,"<4d"),end="")
    else:
        print("        ",end="")
    if line == 70:
        print("     die      ",end="")
    elif line == 65:
        print("      ",end="")
        print(die,end="")
        print("      ",end="")
    else:
        print("              ",end="")
    if devilRndPts >= line and devilRndPts < line+5:
        print(format(devilRndPts,">4d"),"=> ",end="")
    else:
        print("        ",end="")
    print(format(line,">3d"),end="")
    if devilPts >= line and devilPts < line+5:
        print(" <=",format(devilPts,"<4d"),end="")
    else:
        print("        ",end="")
    print()
def printBoard(die,myPts,devilPts,myTurn,myRndPts,devilRndPts):
    printTitle()
    printYouAndDevil(myTurn)
    printTurnScore()
    for i in range(100,-5,-5):
        printNumberLine(i,die,myPts,devilPts,myTurn,myRndPts,devilRndPts)
    print()

def gamePlay(die, myPts, devilPts, myTurn, myRndPts, devilRndPts, playGame):
    while myTurn:
        response = input("[r]oll or [p]ass or [q]uit\n")
        if response == 'r':
            diceNum = [1, 2, 3, 4, 5, 6]
            die = (random.choice(diceNum))
            if die == 1:
                print("You rolled a 1 \nYou're turn ends")
                time.sleep(2)
                myTurn = False
                return playGame, myTurn, myPts
            else:
                myRndPts = die + myRndPts
                printBoard(die, myPts, devilPts, myTurn, myRndPts, devilRndPts)
                print("You rolled a", die)
                time.sleep(1)
                myTurn = True

        elif response == 'p':
            myPts = myPts + myRndPts
            printBoard(die, myPts, devilPts, myTurn, myRndPts, devilRndPts)
            print("You passed")
            time.sleep(2)
            myTurn = False
            return playGame, myTurn, myPts
        elif response == 'q':
            print("You quit. Loser.")
            time.sleep(2)
            playGame = False
            return playGame, myTurn, myPts
            quit()
        else:
            print("Try again.")
            time.sleep(2)

def devilGamePlay(die, myPts, devilPts, myTurn, myRndPts, devilRndPts, playGame):
    while not myTurn:
        diceNum = [1, 2, 3, 4, 5, 6]
        die = (random.choice(diceNum))
        if die == 1:
            printBoard(die, myPts, devilPts, myTurn, myRndPts, devilRndPts)
            print("Devil rolled a", die, "\nHis turn ends.")
            time.sleep(3)
            myTurn = True
            return playGame, myTurn, devilPts
        if devilRndPts >= 21 and devilPts >= myPts:
            devilPts = devilPts + devilRndPts
            printBoard(die, myPts, devilPts, myTurn, myRndPts, devilRndPts)
            print("Devil passes.")
            time.sleep(3)
            myTurn = True
            return myTurn, devilRndPts
        if devilRndPts >= 30 and devilPts <= myPts:
            devilPts = devilPts + devilRndPts
            printBoard(die, myPts, devilPts, myTurn, myRndPts, devilRndPts)
            print("Devil passes.")
            time.sleep(3)
            myTurn = True
            return playGame, myTurn, devilPts
        else:
            devilRndPts = devilRndPts + die
            printBoard(die, myPts, devilPts, myTurn, myRndPts, devilRndPts)
            print("Devil rolled a", die)
            time.sleep(3)
            myTurn = False

def main():
    die = 0
    myPts = 0
    devilPts = 0
    myTurn = True
    myRndPts = 0
    devilRndPts = 0
    playGame = True
    while playGame:
        if myTurn:
            printBoard(die, myPts, devilPts, myTurn, myRndPts, devilRndPts)
            playGame, myTurn, myPts = gamePlay(die, myPts, devilPts, myTurn, myRndPts, devilRndPts, playGame)
            time.sleep(2)
            if myPts >= 100:
                print("Congratulations Winner!!!")
                playGame = False
        else:
            playGame, myTurn, devilPts = devilGamePlay(die, myPts, devilPts, myTurn, myRndPts, devilRndPts, playGame)
            if devilPts >= 100:
                print("Devil is the winner.")
                time.sleep(2)
                playGame = False

main()